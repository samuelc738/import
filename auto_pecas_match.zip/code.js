const STORAGE_KEY = "santanderCatalogHubV1";
const LEGACY_KEYS = ["santanderCatalogV2", "santanderCatalogV3", "santanderCatalogV4", "santanderCatalogSharedV1", "santanderCatalogSharedV2"];
const MIN_UI_HEIGHT = 320;
const MAX_UI_HEIGHT = 1000;
const VARIANT_SUFFIXES = ["desktop", "desd", "desk", "mobile", "mobi", "tablet"];
const DEFAULT_REMOTE_URL = "https://raw.githubusercontent.com/samuelc738/import/main/catalogo.json";
const HIDDEN_FLAG = "apHidden";
const SESSION_KEY = "apSession";
/* taxonomia e lauda gravadas na peça: o Ajustar acha a peça certa mesmo se ela for renomeada */
const TAX_FLAG = "apTaxonomy";
const LAUDA_FLAG = "apLauda";
/* campo da lauda gravado em cada camada de texto: sobrevive a renomeação */
const FIELD_FLAG = "apField";
/* posição da camada no componente original (ordem de leitura), para peças antigas */
const ORIG_FLAG = "apOrigName";
/* formato da peça (detectado ou escolhido à mão): o Exportar usa antes do nome */
const FMT_FLAG = "apFormat";
figma.showUI(__html__, { width: 460, height: 720, themeColors: true });

function normalize(value) {
  return (value || "").toString().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLowerCase().replace(/[_\-]+/g, " ").replace(/[^\w\s]/g, " ")
    .replace(/\s+/g, " ").trim();
}
function slug(value) { return normalize(value); }
/* limite da lauda vale por linha quando o campo tem varias linhas */
function longestLine(v) { return String(v || "").split("\n").reduce((m, x) => Math.max(m, x.length), 0); }
function normalizeText(value) {
  return String(value == null ? "" : value)
    .replace(/\u00a0/g, " ")
    .replace(/[\u2018\u2019\u201b]/g, "'")
    .replace(/[\u201c\u201d]/g, '"')
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/\u2026/g, "...")
    .replace(/\r\n?/g, "\n")
    .replace(/[ \t]+/g, " ")
    .replace(/ *\n */g, "\n")
    .trim();
}
function splitSuffix(rawName) {
  const name = String(rawName || "").trim();
  const lower = name.toLowerCase();
  for (const suffix of VARIANT_SUFFIXES) {
    for (const separator of ["_", "-", " "]) {
      const ending = separator + suffix;
      if (lower.endsWith(ending)) return { base: name.slice(0, -ending.length).trim(), suffix };
    }
  }
  return { base: name, suffix: "" };
}
function taxonomyName(line, suffix) {
  if (!suffix) return line;
  return /[_\-\s]$/.test(line) ? line + suffix : line + "_" + suffix;
}
function isValidCatalog(catalog) {
  if (!catalog || !catalog.formats || typeof catalog.formats !== "object" || Array.isArray(catalog.formats)) return false;
  return Object.keys(catalog.formats).every(key => {
    const entry = catalog.formats[key];
    return entry && Array.isArray(entry.variants);
  });
}
function toList(arrayValue, rawValue) {
  const source = Array.isArray(arrayValue) ? arrayValue.slice() : String(rawValue || "").split(",");
  const seen = {}, out = [];
  source.forEach(item => {
    const value = String(item || "").trim();
    const key = normalize(value);
    if (!value || !key || seen[key]) return;
    seen[key] = true;
    out.push(value);
  });
  return out;
}
function normalizeEntry(entry, fallbackName) {
  const aliases = toList(entry.aliases, entry.aliasesRaw);
  const sizes = toList(entry.sizes, entry.sizesRaw);
  return {
    displayName: entry.displayName || fallbackName,
    aliases, sizes,
    aliasesRaw: aliases.join(", "),
    sizesRaw: sizes.join(", "),
    maxPerRow: Number(entry.maxPerRow) || 0,
    variants: (entry.variants || []).map(v => ({ suffix: v.suffix || "", key: v.key || "", figmaName: v.figmaName || "" }))
  };
}
function normalizeCatalog(input) {
  const catalog = { version: input.version || "1", updatedAt: input.updatedAt || "", formats: {} };
  Object.keys(input.formats || {}).forEach(key => { catalog.formats[key] = normalizeEntry(input.formats[key], key); });
  return catalog;
}
/* hideUnmatched: ocultar camadas de texto que NAO tem campo na lauda.
   Desligado por padrao: peca costuma ter texto fixo (legal, assinatura)
   que nunca vai na lauda e nao pode sumir. */
/* textos fixos do componente: nunca vêm na lauda, então ficar com o texto original é o esperado */
const DEFAULT_FIXED_TEXT = ["Disclaimer", "Legal", "IA text", "Assinatura", "Selo", "Rodapé"];
const DEFAULT_ADJUST_PREFS = { scope: "selection", autoApply: true, reveal: true, skipMixed: true, hideUnmatched: false, fixedText: DEFAULT_FIXED_TEXT, blockEmail: true };
/* formato de email: nome ou variável contém "email"/"emkt" */
function isEmailFormat(entry, key) {
  const terms = [entry && entry.displayName, key].concat((entry && entry.aliases) || []);
  return terms.some(t => /(^|\s)(e ?mail|emkt)(\s|$)/.test(normalize(t)));
}
/* ordem natural: _2_ antes de _10_ */
const natCmp = (a, b) => String(a).localeCompare(String(b), "pt-BR", { numeric: true, sensitivity: "base" });
function isFixedText(name, list) {
  const n = " " + normalize(name) + " ";
  return (list || []).some(t => { const k = normalize(t); return k && n.indexOf(" " + k + " ") !== -1; });
}
function normalizeAdjustPrefs(input) {
  const prefs = input || {};
  return {
    scope: prefs.scope === "page" ? "page" : "selection",
    autoApply: prefs.autoApply !== false,
    reveal: prefs.reveal !== false,
    skipMixed: prefs.skipMixed !== false,
    hideUnmatched: prefs.hideUnmatched === true,
    blockEmail: prefs.blockEmail !== false,
    importPick: prefs.importPick === "new" ? "new" : "all",
    rememberSession: prefs.rememberSession !== false,
    fixedText: Array.isArray(prefs.fixedText) ? prefs.fixedText.map(x => String(x || "").trim()).filter(Boolean) : DEFAULT_FIXED_TEXT.slice(),
    /* guias de primeira vez já dispensados (por aba) */
    seenTips: Array.isArray(prefs.seenTips) ? prefs.seenTips.map(String) : []
  };
}
function normalizeTheme(value) {
  return value === "light" || value === "dark" ? value : "auto";
}
async function readState() {
  const active = await figma.clientStorage.getAsync(STORAGE_KEY);
  if (active) {
    try {
      const parsed = JSON.parse(active);
      if (parsed.catalog && isValidCatalog(parsed.catalog)) {
        parsed.remoteUrl = DEFAULT_REMOTE_URL;
        parsed.rowPrefs = parsed.rowPrefs || {};
        parsed.adjustPrefs = normalizeAdjustPrefs(parsed.adjustPrefs);
        parsed.theme = normalizeTheme(parsed.theme);
        return parsed;
      }
    } catch (_) {}
  }
  for (const key of LEGACY_KEYS) {
    const raw = await figma.clientStorage.getAsync(key);
    if (!raw) continue;
    try {
      const parsed = JSON.parse(raw);
      const oldCatalog = parsed.catalog || parsed;
      if (isValidCatalog(oldCatalog)) {
        const migrated = { catalog: normalizeCatalog(oldCatalog), remoteUrl: DEFAULT_REMOTE_URL, syncedAt: "", dirty: false, rowPrefs: {}, adjustPrefs: normalizeAdjustPrefs(null), theme: "auto" };
        await saveState(migrated);
        return migrated;
      }
    } catch (_) {}
  }
  return { catalog: { version: "1", updatedAt: "", formats: {} }, remoteUrl: DEFAULT_REMOTE_URL, syncedAt: "", dirty: false, rowPrefs: {}, adjustPrefs: normalizeAdjustPrefs(null), theme: "auto" };
}
async function saveState(state) { await figma.clientStorage.setAsync(STORAGE_KEY, JSON.stringify(state)); }
function candidateUrls(url) {
  const raw = String(url || "").trim() || DEFAULT_REMOTE_URL;
  if (raw.indexOf("githubusercontent.com") !== -1) return [raw];
  const idMatch = raw.match(/\/file\/d\/([^/]+)/) || raw.match(/[?&]id=([^&]+)/);
  if (idMatch) {
    const id = idMatch[1];
    return ["https://drive.usercontent.google.com/download?id=" + id + "&export=download",
            "https://drive.google.com/uc?export=download&id=" + id];
  }
  return [raw];
}
async function fetchRemoteCatalog(url) {
  const urls = candidateUrls(url);
  let lastError = "";
  for (const target of urls) {
    try {
      const finalUrl = target + (target.indexOf("?") !== -1 ? "&" : "?") + "_=" + Date.now();
      const response = await fetch(finalUrl);
      if (!response.ok) { lastError = "HTTP " + response.status; continue; }
      const text = await response.text();
      if (text.trim().charAt(0) !== "{") { lastError = "O link nao devolveu JSON."; continue; }
      const raw = JSON.parse(text);
      const catalog = normalizeCatalog(raw.catalog || raw);
      if (!isValidCatalog(catalog)) { lastError = "JSON remoto invalido."; continue; }
      return catalog;
    } catch (error) { lastError = error && error.message ? error.message : String(error); }
  }
  throw new Error(lastError || "Nao foi possivel baixar o catalogo.");
}
async function extractComponentsFromFile() {
  if (typeof figma.loadAllPagesAsync === "function") await figma.loadAllPagesAsync();
  const items = [];
  for (const page of figma.root.children) {
    if (typeof page.loadAsync === "function") await page.loadAsync();
    const components = page.findAll(node => node.type === "COMPONENT");
    for (const component of components) {
      const parsed = splitSuffix(component.name);
      items.push({ name: component.name, key: component.key, base: parsed.base, suffix: parsed.suffix });
    }
  }
  return items;
}
function mergeLibrary(catalog, components) {
  const next = normalizeCatalog(catalog);
  for (const component of components) {
    const key = slug(component.base);
    if (!key) continue;
    if (!next.formats[key]) next.formats[key] = normalizeEntry({ displayName: component.base, variants: [] }, component.base);
    const entry = next.formats[key];
    const variant = entry.variants.find(v => v.suffix === component.suffix);
    if (!variant) entry.variants.push({ suffix: component.suffix, key: component.key, figmaName: component.name });
    else { variant.key = component.key; variant.figmaName = component.name; }
  }
  Object.keys(next.formats).forEach(key => {
    const parsed = splitSuffix(next.formats[key].displayName || key);
    if (!parsed.suffix) return;
    const baseKey = slug(parsed.base);
    if (baseKey === key || !baseKey) return;
    if (!next.formats[baseKey]) next.formats[baseKey] = normalizeEntry({ displayName: parsed.base, variants: [] }, parsed.base);
    next.formats[key].variants.forEach(v => {
      const suffix = v.suffix || parsed.suffix;
      const target = next.formats[baseKey].variants.find(x => x.suffix === suffix);
      if (target) Object.assign(target, v, { suffix });
      else next.formats[baseKey].variants.push(Object.assign({}, v, { suffix }));
    });
    delete next.formats[key];
  });
  next.version = String(Date.now());
  next.updatedAt = new Date().toISOString();
  return next;
}
function findConflicts(catalog) {
  const bySize = {};
  Object.keys(catalog.formats || {}).forEach(key => {
    const entry = normalizeEntry(catalog.formats[key], key);
    entry.sizes.forEach(size => {
      const t = normalize(size);
      if (!t) return;
      if (!bySize[t]) bySize[t] = [];
      bySize[t].push(entry.displayName || key);
    });
  });
  const conflicts = [];
  Object.keys(bySize).forEach(size => { if (bySize[size].length > 1) conflicts.push({ size, formats: bySize[size] }); });
  return conflicts;
}
function catalogHealth(catalog) {
  let missingKeys = 0, noVariants = 0, noAliases = 0, variantCount = 0;
  Object.keys(catalog.formats || {}).forEach(key => {
    const entry = normalizeEntry(catalog.formats[key], key);
    if (!entry.variants.length) noVariants++;
    if (!entry.aliases.length) noAliases++;
    entry.variants.forEach(v => { variantCount++; if (!v.key) missingKeys++; });
  });
  return { formats: Object.keys(catalog.formats || {}).length, variants: variantCount, missingKeys, noVariants, noAliases, conflicts: findConflicts(catalog) };
}
/* Reconhecimento por pontuação: cruza nome e tamanho do mesmo formato.
   nome/variável = 10 pts (+ desempate pelo termo mais longo) · tamanho = 5 pts.
   Formato com nome E tamanho na taxonomia vence quem só tem o tamanho.
   Se só o tamanho bate e ele é de mais de um formato, é ambíguo: não escolhe. */
function createMatchers(catalog) {
  const list = [];
  Object.keys(catalog.formats || {}).forEach(baseKey => {
    const entry = normalizeEntry(catalog.formats[baseKey], baseKey);
    const names = [entry.displayName || baseKey].concat(entry.aliases).map(normalize).filter(Boolean);
    const sizes = entry.sizes.map(normalize).filter(Boolean);
    list.push({ baseKey, names, sizes });
  });
  return list;
}
function hasWord(hay, term) { return (" " + hay + " ").indexOf(" " + term + " ") !== -1; }
function scoreFormats(line, matchers) {
  const n = normalize(line), out = [];
  matchers.forEach(m => {
    let name = "", size = false;
    m.names.forEach(t => { if (n.indexOf(t) !== -1 && t.length > name.length) name = t; });
    m.sizes.forEach(t => { if (hasWord(n, t)) size = true; });
    if (!name && !size) return;
    const score = (name ? 10 + name.length / 1000 + (hasWord(n, name) ? 0.5 : 0) : 0) + (size ? 5 : 0);
    out.push({ baseKey: m.baseKey, score, byName: !!name, bySize: size,
      source: name && size ? "nome+tamanho" : name ? "nome" : "tamanho" });
  });
  out.sort((a, b) => b.score - a.score);
  return out;
}
function findFormat(line, matchers) {
  const ranked = scoreFormats(line, matchers);
  if (!ranked.length) return null;
  const top = ranked[0];
  /* só tamanho e empatado com outro formato: ambíguo */
  if (!top.byName && ranked.length > 1 && ranked[1].score === top.score) return null;
  return top;
}
function isAmbiguous(line, matchers) {
  const r = scoreFormats(line, matchers);
  return r.length > 1 && !r[0].byName && r[1].score === r[0].score;
}
/* ================= MATCH CAMPO x CAMADA ================= */
const LAYER_GROUPS = [
  { id: "titulo", terms: ["titulo", "title", "headline", "head", "chamada", "h1"] },
  { id: "subtitulo", terms: ["subtitulo", "subtitle", "sub", "apoio", "h2"] },
  { id: "texto", terms: ["texto", "text", "txt", "copy", "corpo", "body", "mensagem", "descricao", "descritivo"] },
  { id: "cta", terms: ["cta", "botao", "button", "link", "acao", "call to action"] },
  { id: "legal", terms: ["legal", "disclaimer", "rodape", "footer", "obs", "observacao"] },
  { id: "selo", terms: ["selo", "tag", "flag", "etiqueta"] }
];
function groupOf(name) {
  const value = normalize(name);
  if (!value) return "";
  for (const group of LAYER_GROUPS) {
    for (const term of group.terms) {
      if (value === term || value.indexOf(term) === 0 || (" " + value + " ").indexOf(" " + term + " ") !== -1) return group.id;
    }
  }
  return "";
}
/* Um nome pode declarar duas variacoes separadas por "/":
     "Texto descritivo 02 / Subtexto"  →  ["texto descritivo 02", "subtexto"]
   Vale para a camada do Figma e para a chave da lauda. Antes so o ultimo
   segmento era considerado (split("/").pop()), o que quebrava quando a lauda
   usava o primeiro nome. */
function layerAliases(name) {
  const raw = String(name || "").replace(/[#*\u2022]/g, "");
  const parts = raw.split("/").map(p => normalize(p)).filter(Boolean);
  const seen = {}, out = [];
  parts.forEach(p => { if (!seen[p]) { seen[p] = true; out.push(p); } });
  return out.length ? out : [normalize(raw)];
}
/* true quando o nome declara variacoes — sinal de que a camada e um slot de lauda */
function hasAliasMark(name) { return String(name || "").indexOf("/") !== -1; }
/* "CTA 2" → { base:"cta", index:2 }   "Texto descritivo 02" → { base:"texto descritivo", index:2 }
   Nome terminado em numero indica uma serie de slots: CTA, CTA 2, CTA 3... */
function numberedBase(name) {
  const norm = normalize(name);
  /* exige separador antes do numero: "CTA 2" sim, "Banner 2024" nao */
  const m = norm.match(/^(.+?)\s+0*(\d{1,2})$/);
  if (!m || !m[1]) return null;
  return { base: m[1].trim(), index: parseInt(m[2], 10) };
}
/* a serie existe na lauda? (o campo "CTA" justifica a camada "CTA 2") */
function seriesInLauda(name, fields) {
  const info = numberedBase(name);
  if (!info || !info.base) return false;
  for (const f of fields) {
    for (const n of f.norms) {
      if (n === info.base) return true;
      const other = numberedBase(n);
      if (other && other.base === info.base) return true;
    }
  }
  return false;
}
function cleanLayerName(name) { return layerAliases(name)[0] || ""; }
function aliasesIntersect(a, b) {
  for (let i = 0; i < a.length; i++) if (b.indexOf(a[i]) !== -1) return true;
  return false;
}
function aliasesStartWith(a, b) {
  for (let i = 0; i < a.length; i++)
    for (let j = 0; j < b.length; j++)
      if (a[i].indexOf(b[j]) === 0 || b[j].indexOf(a[i]) === 0) return true;
  return false;
}
/* grupo semantico considerando todos os apelidos */
function groupOfAny(name) {
  const list = layerAliases(name);
  for (let i = 0; i < list.length; i++) { const g = groupOf(list[i]); if (g) return g; }
  return "";
}
function collectTextNodes(node, includeHidden) {
  if (node.type === "TEXT") return [node];
  if (typeof node.findAll !== "function") return [];
  return node.findAll(child => child.type === "TEXT" && (includeHidden || child.visible !== false));
}
const FONT_CACHE = {};
async function loadFont(font) {
  if (!font || font === figma.mixed) return;
  const key = font.family + "|" + font.style;
  if (FONT_CACHE[key]) return FONT_CACHE[key];
  FONT_CACHE[key] = figma.loadFontAsync(font).catch(error => { delete FONT_CACHE[key]; throw error; });
  return FONT_CACHE[key];
}
async function loadFontsOf(textNode) {
  const fonts = [];
  if (textNode.fontName === figma.mixed) {
    const length = textNode.characters.length;
    for (let i = 0; i < length; i++) {
      const font = textNode.getRangeFontName(i, i + 1);
      if (font !== figma.mixed && !fonts.some(f => f.family === font.family && f.style === font.style)) fonts.push(font);
    }
  } else fonts.push(textNode.fontName);
  await Promise.all(fonts.map(loadFont));
  return fonts;
}
/* O Figma renomeia sozinho a camada de texto que nunca foi renomeada à mão
   (autoRename). Escrever o texto da lauda trocava "Título" por "Finalize o…"
   e o Ajustar deixava de achar o campo. Travamos o nome antes de escrever. */
function writeText(textNode, value, fieldKey) {
  const name = textNode.name;
  try { if ("autoRename" in textNode) textNode.autoRename = false; } catch (_) {}
  textNode.characters = value;
  if (textNode.name !== name) { try { textNode.name = name; } catch (_) {} }
  if (fieldKey) { try { textNode.setPluginData(FIELD_FLAG, fieldKey); } catch (_) {} }
}
function storedField(textNode) { try { return textNode.getPluginData(FIELD_FLAG) || ""; } catch (_) { return ""; } }
function isMixedFormatting(textNode) {
  try {
    if (textNode.fontName === figma.mixed) return true;
    if (textNode.fills === figma.mixed) return true;
    if (textNode.fontSize === figma.mixed) return true;
  } catch (_) {}
  return false;
}
function textTargets(root, includeHidden) {
  return collectTextNodes(root, includeHidden).map(textNode => {
    const chain = [];
    let cursor = textNode.parent;
    while (cursor && cursor !== root.parent && chain.length < 8) {
      chain.push(cursor);
      if (cursor === root) break;
      cursor = cursor.parent;
    }
    return { textNode, chain };
  });
}
function prepareFields(lauda) {
  return (lauda && lauda.fields ? lauda.fields : []).map(field => {
    const value = String(field.value == null ? "" : field.value);
    return { key: field.key, norm: cleanLayerName(field.key), norms: layerAliases(field.key),
      group: groupOfAny(field.key), value,
      limit: Number(field.limit) || 0, empty: field.empty === true || value.trim() === "", used: false };
  });
}
function matchFields(node, lauda, includeHidden) {
  const fields = prepareFields(lauda);
  const targets = textTargets(node, includeHidden)
    .sort((a, b) => { const ay = a.textNode.absoluteTransform ? a.textNode.absoluteTransform[1][2] : a.textNode.y, by = b.textNode.absoluteTransform ? b.textNode.absoluteTransform[1][2] : b.textNode.y;
      const ax = a.textNode.absoluteTransform ? a.textNode.absoluteTransform[0][2] : a.textNode.x, bx = b.textNode.absoluteTransform ? b.textNode.absoluteTransform[0][2] : b.textNode.x;
      return (ay - by) || (ax - bx); });
  const pending = [];
  /* Camada com vários nomes ("DISMISS / BOTAO 2") pode casar com vários campos
     da lauda. Fica com o campo que TEM texto; os outros nomes dela são
     consumidos, para não sobrarem e irem parar em outra camada. */
  const pickField = names => {
    const all = fields.filter(f => !f.used && aliasesIntersect(names, f.norms));
    if (!all.length) return null;
    const best = all.find(f => !f.empty) || all[0];
    all.forEach(f => { if (f !== best) { f.used = true; f.absorbed = true; } });
    return best;
  };
  /* 0) campo gravado na própria camada: exato, mesmo com a camada renomeada */
  const preset = new Map();
  targets.forEach(target => {
    const k = normalize(storedField(target.textNode));
    if (!k) return;
    const f = fields.find(x => !x.used && x.norms.indexOf(k) !== -1);
    if (f) { f.used = true; preset.set(target.textNode, f); }
  });
  /* camada auto-renomeada pelo Figma (nome = começo do próprio texto) não é nome de campo */
  const autoNamed = t => {
    const n = normalize(t.name), c = normalize(String(t.characters || "").slice(0, Math.max(t.name.length + 4, 40)));
    return !!n && n.length > 3 && c.indexOf(n) === 0;
  };
  /* 1) apelido exato do no de texto  2) apelido exato de um container */
  targets.forEach(target => {
    const names = layerAliases(target.textNode.name);
    let field = preset.get(target.textNode) || null;
    if (!field && !autoNamed(target.textNode)) field = pickField(names);
    let container = null;
    if (!field) {
      for (const box of target.chain) {
        if (box === node) break;
        const boxNames = layerAliases(box.name);
        const hit = pickField(boxNames);
        if (hit) { field = hit; container = box; break; }
      }
    }
    if (field) field.used = true;
    /* o "/" pode estar na camada de texto OU num container acima dela.
       Guardamos qual no carrega a marca, para ocultar o container certo. */
    let slotNode = hasAliasMark(target.textNode.name) ? target.textNode : null;
    if (!slotNode) {
      for (const box of target.chain) {
        if (box === node) break;
        if (hasAliasMark(box.name)) { slotNode = box; break; }
      }
    }
    pending.push({ textNode: target.textNode, chain: target.chain, field: field || null, container,
      names, slot: !!slotNode, slotNode: slotNode });
  });
  /* 3) prefixo  4) grupo semantico do container  5) grupo do proprio texto */
  pending.forEach(item => {
    if (item.field) return;
    const auto = autoNamed(item.textNode);
    let field = auto ? null : fields.find(f => !f.used && aliasesStartWith(item.names, f.norms));
    /* container genérico ("Texto") não decide qual campo é qual quando o nome da camada se perdeu */
    if (!field && !auto) {
      for (const box of item.chain) {
        if (box === node) break;
        const group = groupOfAny(box.name);
        if (group) { field = fields.find(f => !f.used && f.group === group); if (field) { item.container = box; break; } }
      }
    }
    if (!field && !auto) {
      const group = groupOfAny(item.textNode.name);
      if (group) field = fields.find(f => !f.used && f.group === group);
    }
    if (field) { field.used = true; item.field = field; }
  });
  /* 6) peças antigas com camadas auto-renomeadas: pela ordem de leitura.
     Camadas sem campo e campos sem camada são casados na ordem em que
     aparecem (de cima para baixo), a mesma ordem da lauda. */
  const looseNodes = pending.filter(p => !p.field && !p.slot && autoNamed(p.textNode));
  const looseFields = fields.filter(f => !f.used && !f.empty);
  if (looseNodes.length && looseFields.length) {
    looseNodes.slice(0, looseFields.length).forEach((p, i) => { p.field = looseFields[i]; looseFields[i].used = true; p.byOrder = true; });
  }
  /* camada numerada cuja serie aparece na lauda tambem e um slot declarado:
     a peca tem CTA e CTA 2, a lauda so trouxe CTA → o segundo some. */
  pending.forEach(item => {
    if (item.field || item.slot) return;
    const own = seriesInLauda(item.textNode.name, fields);
    if (own) { item.slot = true; item.numbered = true; item.slotNode = item.slotNode || item.textNode; return; }
    for (const box of item.chain) {
      if (box === node) break;
      if (seriesInLauda(box.name, fields)) { item.slot = true; item.numbered = true; item.slotNode = box; break; }
    }
  });
  /* sobrou 1 camada e 1 campo: só casa se o campo tem texto e a camada não é texto fixo
     (antes, um campo vazio como LABELTAG ocultava a legenda "IA text") */
  const orphanNodes = pending.filter(p => !p.field && !p.slot && !isFixedText(p.textNode.name, (lauda && lauda.fixedText) || DEFAULT_FIXED_TEXT));
  const orphanFields = fields.filter(f => !f.used && !f.empty);
  if (orphanNodes.length === 1 && orphanFields.length === 1) {
    orphanNodes[0].field = orphanFields[0];
    orphanFields[0].used = true;
  }
  return { fields, pending };
}
function hideTarget(item, root) {
  const target = item.container || item.textNode;
  if (target === root) return null;
  target.visible = false;
  try { target.setPluginData(HIDDEN_FLAG, "1"); } catch (_) {}
  let parent = target.parent, hiddenName = target.name, climbed = 0;
  while (parent && parent !== root && parent.type !== "PAGE" && climbed < 8) {
    const children = parent.children || [];
    if (children.some(child => child.visible !== false)) break;
    parent.visible = false;
    try { parent.setPluginData(HIDDEN_FLAG, "1"); } catch (_) {}
    hiddenName = parent.name;
    parent = parent.parent;
    climbed++;
  }
  return hiddenName;
}
/* camada oculta dentro da peça (ela própria ou um container acima) */
function hiddenIn(textNode, root) {
  let cur = textNode;
  while (cur && cur !== root && cur.type !== "PAGE") { if (cur.visible === false) return true; cur = cur.parent; }
  return false;
}
/* torna visível a camada e os containers ocultos até a peça (ocultos no componente) */
function showChain(textNode, root) {
  let cur = textNode, n = 0;
  while (cur && cur !== root && cur.type !== "PAGE" && n < 12) {
    if (cur.visible === false) { cur.visible = true; try { cur.setPluginData(HIDDEN_FLAG, ""); } catch (_) {} }
    cur = cur.parent; n++;
  }
}
function revealTarget(item, root) {
  const chainUp = [];
  let cursor = item.textNode;
  while (cursor && cursor !== root.parent && chainUp.length < 10) { chainUp.push(cursor); if (cursor === root) break; cursor = cursor.parent; }
  let revealed = 0;
  chainUp.forEach(node => {
    if (node === root || node.visible !== false) return;
    let owned = false;
    try { owned = node.getPluginData(HIDDEN_FLAG) === "1"; } catch (_) {}
    if (!owned) return;
    node.visible = true;
    try { node.setPluginData(HIDDEN_FLAG, ""); } catch (_) {}
    revealed++;
  });
  return revealed;
}
async function applyLauda(node, lauda, options) {
  const opts = options || {};
  const report = { applied: 0, hidden: 0, hiddenNames: [], orphanHidden: 0, orphanNames: [], slotHidden: 0, numberedHidden: 0, skipped: [], warnings: [] };
  if (!lauda || !lauda.fields || !lauda.fields.length) return report;
  /* inclui camadas ocultas no componente (ex.: "DISMISS / BOTAO 2" desligada) */
  const { fields, pending } = matchFields(node, lauda, true);
  /* 1a passada: campos com correspondencia */
  for (const item of pending) {
    const wasHidden = hiddenIn(item.textNode, node);
    if (!item.field) { if (!item.slot && !wasHidden) report.skipped.push(item.textNode.name); continue; }
    if (item.field.empty) {
      if (wasHidden) { try { item.textNode.setPluginData(FIELD_FLAG, item.field.key); } catch (_) {} continue; }
      try { item.textNode.setPluginData(FIELD_FLAG, item.field.key); } catch (_) {}
      try {
        const hiddenName = hideTarget(item, node);
        report.hidden++;
        if (hiddenName) report.hiddenNames.push(hiddenName);
      } catch (error) { report.warnings.push("nao foi possivel ocultar " + item.field.key); }
      continue;
    }
    try {
      await loadFontsOf(item.textNode);
      writeText(item.textNode, item.field.value, item.field.key);
      /* tinha texto na lauda: a camada oculta no componente reaparece */
      if (wasHidden) { showChain(item.textNode, node); report.shown = (report.shown || 0) + 1; }
      report.applied++;
      if (item.field.limit && longestLine(item.field.value) > item.field.limit)
        report.warnings.push(item.field.key + ": " + longestLine(item.field.value) + "/" + item.field.limit + " car.");
    } catch (error) { report.warnings.push("fonte " + (error && error.message ? error.message : String(error))); }
  }
  /* 2a passada: camadas sem campo na lauda.
     So depois de aplicar o resto, para o colapso de container ver o estado final. */
  for (const item of pending) {
    if (item.field) continue;
    /* camada já oculta no componente e sem campo: continua como está */
    if (hiddenIn(item.textNode, node)) continue;
    /* camada com "/" no nome declara ser um slot de lauda: some sempre que
       nenhum dos nomes aparecer preenchido. Texto fixo da peca (legal,
       assinatura) nao tem barra e continua protegido pela preferencia. */
    if (!item.slot && !opts.hideUnmatched) continue;
    try {
      const hiddenName = hideTarget({ textNode: item.textNode, container: item.slotNode || null }, node);
      report.orphanHidden++;
      if (hiddenName) report.orphanNames.push(hiddenName);
      if (item.slot) report.slotHidden++;
      if (item.numbered) report.numberedHidden++;
    } catch (_) {}
  }
  fields.filter(f => !f.used && !f.empty && !f.absorbed).forEach(f => report.warnings.push("campo " + f.key + " sem camada"));
  return report;
}

/* ================= AJUSTAR ================= */
function looksLikePiece(node) {
  if (!node || node.visible === false) return false;
  const type = node.type;
  if (type !== "FRAME" && type !== "GROUP" && type !== "COMPONENT" && type !== "INSTANCE" && type !== "SECTION") return false;
  if (typeof node.findAll !== "function") return false;
  return node.findAll(child => child.type === "TEXT").length > 0;
}
/* operação longa em andamento pode ser cancelada pela UI */
let cancelFlag = false;
const tick = () => new Promise(r => setTimeout(r, 0));
async function collectPieces(scope, ids) {
  /* peças de uma importação específica, pelo id */
  if (scope === "ids" && Array.isArray(ids)) {
    const out = [];
    for (const id of ids) { try { const n = await figma.getNodeByIdAsync(id); if (n && !n.removed && typeof n.findAll === "function") out.push(n); } catch (_) {} }
    return out;
  }
  if (scope === "page") {
    if (typeof figma.currentPage.loadAsync === "function") await figma.currentPage.loadAsync();
    return figma.currentPage.children.filter(looksLikePiece);
  }
  return figma.currentPage.selection.filter(node => !!node && (typeof node.findAll === "function" || node.type === "TEXT"));
}
function diffPiece(node, lauda, options) {
  const opts = options || {};
  const { fields, pending } = matchFields(node, lauda, true);
  const rows = [], extras = [];
  pending.forEach(item => {
    const textNode = item.textNode;
    const box = item.container || item.slotNode;
    const isHidden = hiddenIn(textNode, node) || (box && box !== textNode && box.visible === false);
    let owned = false;
    try { owned = (box || textNode).getPluginData(HIDDEN_FLAG) === "1"; } catch (_) {}
    /* camada sem campo correspondente na lauda */
    if (!item.field) {
      if (!item.slot && !isHidden && !isFixedText(textNode.name, opts.fixedText)) extras.push(textNode.name);
      /* slot declarado com "/" sempre entra no diff; camada comum so com a preferencia */
      if (!item.slot && !opts.hideUnmatched) return;
      const slotBox = item.slotNode && item.slotNode !== textNode ? item.slotNode : null;
      const slotHidden = isHidden || (slotBox && slotBox.visible === false);
      rows.push({ key: (slotBox ? slotBox.name : textNode.name),
        current: String(textNode.characters || ""), next: "",
        action: slotHidden ? "same" : "hide", orphan: true, slot: !!item.slot, numbered: !!item.numbered,
        hidden: !!slotHidden, ownedHide: owned,
        mixed: false, limit: 0, over: false,
        textId: textNode.id, containerId: slotBox ? slotBox.id : "", layer: textNode.name });
      return;
    }
    const current = String(textNode.characters || "");
    const next = item.field.value;
    let action = "same";
    if (item.field.empty) action = isHidden ? "same" : "hide";
    else if (isHidden) action = "show";
    else if (normalizeText(current) !== normalizeText(next)) action = "update";
    rows.push({ key: item.field.key, current, next, action, hidden: isHidden, ownedHide: owned, byOrder: !!item.byOrder,
      mixed: isMixedFormatting(textNode), limit: item.field.limit,
      over: item.field.limit ? longestLine(next) > item.field.limit : false,
      textId: textNode.id, containerId: item.container ? item.container.id : "", layer: textNode.name });
  });
  return { rows, missing: fields.filter(f => !f.used && !f.empty).map(f => f.key), extras };
}
function tokensOf(value) { return normalize(value).split(" ").filter(Boolean); }
function scorePair(name, lauda) {
  const a = normalize(name), b = normalize(lauda.taxonomy || "");
  if (a && a === b) return 1;
  const ta = tokensOf(name), tb = tokensOf(lauda.taxonomy || "");
  if (!ta.length || !tb.length) return 0;
  const sa = {}, sb = {};
  ta.forEach(t => sa[t] = true); tb.forEach(t => sb[t] = true);
  let hitA = 0, hitB = 0;
  Object.keys(sa).forEach(t => { if (sb[t]) hitA++; });
  Object.keys(sb).forEach(t => { if (sa[t]) hitB++; });
  let score = (hitA / Object.keys(sa).length) * 0.65 + (hitB / Object.keys(sb).length) * 0.35;
  if (a && b && (a.indexOf(b) === 0 || b.indexOf(a) === 0)) score = Math.min(1, score + 0.1);
  return score;
}
function storedTaxonomy(node) {
  try { return node.getPluginData(LAUDA_FLAG) || node.getPluginData(TAX_FLAG) || ""; } catch (_) { return ""; }
}
function assignSelection(nodes, laudas) {
  const map = {}, usedNode = {}, usedLauda = {};
  /* 1) dado gravado na peça: exato, vale mesmo com a peça renomeada.
        Variantes (desktop/mobile) podem dividir a mesma lauda. */
  const byTax = {};
  laudas.forEach((item, li) => { const k = normalize(item.lauda && item.lauda.taxonomy); if (k && byTax[k] === undefined) byTax[k] = li; });
  nodes.forEach((node, ni) => {
    const t = normalize(storedTaxonomy(node));
    if (!t || byTax[t] === undefined) return;
    const li = byTax[t];
    map[ni] = { lauda: laudas[li].lauda, score: 1, source: "data" };
    usedNode[ni] = true; usedLauda[li] = true;
  });
  /* 2) sobrou: semelhança de nome (peças antigas, sem o dado gravado) */
  const pairs = [];
  nodes.forEach((node, ni) => {
    if (usedNode[ni]) return;
    laudas.forEach((item, li) => {
      if (usedLauda[li]) return;
      const score = scorePair(splitSuffix(node.name).base, item.lauda);
      if (score >= 0.45) pairs.push({ ni, li, score });
    });
  });
  pairs.sort((a, b) => b.score - a.score);
  pairs.forEach(pair => {
    if (usedNode[pair.ni] || usedLauda[pair.li]) return;
    usedNode[pair.ni] = true; usedLauda[pair.li] = true;
    map[pair.ni] = { lauda: laudas[pair.li].lauda, score: pair.score, source: "name" };
  });
  return map;
}
async function scanAdjust(laudas, scope, prefs, ids) {
  const opts = normalizeAdjustPrefs(prefs);
  const pieces = await collectPieces(scope, ids);
  if (!pieces.length) return { pieces: [], error: scope === "ids" ? "As pecas desta importacao nao foram encontradas no arquivo — foram apagadas?" : scope === "page" ? "Nenhuma peca encontrada nesta pagina." : "Selecione as pecas no canvas ou troque o escopo para a pagina inteira." };
  const map = assignSelection(pieces, laudas || []);
  const out = [];
  const st0 = await readState(), cat0 = normalizeCatalog(st0.catalog);
  const emailKeys = Object.keys(cat0.formats).filter(k => isEmailFormat(cat0.formats[k], k));
  const emailMatchers = createMatchers({ formats: Object.fromEntries(emailKeys.map(k => [k, cat0.formats[k]])) });
  const total = pieces.length, every = Math.max(1, Math.ceil(total / 40));
  figma.ui.postMessage({ type: "op-progress", op: "scan", done: 0, total });
  for (let index = 0; index < pieces.length; index++) {
    const node = pieces[index];
    if (index % every === 0) {
      figma.ui.postMessage({ type: "op-progress", op: "scan", done: index, total, label: node.name });
      await tick();
      if (cancelFlag) return { pieces: out, cancelled: true, total };
    }
    const pair = map[index];
    if (opts.blockEmail && emailKeys.length && findFormat(node.name, emailMatchers)) { out.push({ id: node.id, name: node.name, matched: true, emailBlocked: true, rows: [], missing: [], extras: [] }); continue; }
    if (!pair) { out.push({ id: node.id, name: node.name, matched: false, rows: [], missing: [], extras: [] }); continue; }
    const lauda = pair.lauda;
    const diff = diffPiece(node, lauda, opts);
    out.push({ id: node.id, name: node.name, matched: true, taxonomy: lauda.taxonomy || "", rows: diff.rows, missing: diff.missing, extras: diff.extras,
      pairSource: pair.source, pairScore: Math.round(pair.score * 100) / 100 });
  }
  return { pieces: out };
}
async function applyAdjust(items, prefs) {
  const options = normalizeAdjustPrefs(prefs);
  const list = items || [];
  const report = { updated: 0, hidden: 0, shown: 0, failed: [], failedIds: [], total: list.length };
  if (!list.length) return report;
  const ids = {};
  list.forEach(item => { ids[item.textId] = true; if (item.containerId) ids[item.containerId] = true; if (item.pieceId) ids[item.pieceId] = true; });
  const idList = Object.keys(ids);
  const resolved = await Promise.all(idList.map(id => figma.getNodeByIdAsync(id).catch(() => null)));
  const nodeById = {};
  idList.forEach((id, index) => { nodeById[id] = resolved[index]; });
  const fontJobs = [];
  list.filter(item => item.action === "show" || item.action === "update").forEach(item => {
    const textNode = nodeById[item.textId];
    if (!textNode || textNode.removed) return;
    try { if (textNode.fontName && textNode.fontName !== figma.mixed) fontJobs.push(loadFont(textNode.fontName)); } catch (_) {}
  });
  await Promise.all(fontJobs.map(job => job.catch(() => null)));
  let done = 0;
  const step = Math.max(10, Math.ceil(list.length / 12));
  /* escritas e reexibicoes primeiro; ocultacoes depois, para o colapso
     de container enxergar o estado final da peca */
  const ordered = list.filter(i => i.action !== "hide").concat(list.filter(i => i.action === "hide"));
  for (const item of ordered) {
    try {
      const textNode = nodeById[item.textId];
      if (!textNode || textNode.removed) { report.failed.push(item.key + ": camada nao encontrada"); report.failedIds.push(item.textId); continue; }
      const rawContainer = item.containerId ? nodeById[item.containerId] : null;
      const pieceNode = item.pieceId ? nodeById[item.pieceId] : null;
      const wrapper = { textNode, container: rawContainer && !rawContainer.removed ? rawContainer : null };
      if (item.action === "hide") { hideTarget(wrapper, pieceNode || textNode.parent); report.hidden++; }
      else {
        if ((item.action === "show" || textNode.visible === false) && options.reveal) {
          if (revealTarget({ textNode }, pieceNode || textNode.parent)) report.shown++;
        }
        /* reexibir aprovado na revisão: abre também o que estava oculto no componente */
        if (item.action === "show" && pieceNode && hiddenIn(textNode, pieceNode)) { showChain(textNode, pieceNode); report.shown++; }
        if (options.skipMixed && isMixedFormatting(textNode)) { report.failed.push(item.key + ": formatacao mista, revisar a mao"); report.failedIds.push(item.textId); }
        else {
          await loadFontsOf(textNode);
          writeText(textNode, String(item.value == null ? "" : item.value), item.key);
          report.updated++;
        }
      }
    } catch (error) { report.failed.push(item.key + ": " + (error && error.message ? error.message : String(error))); report.failedIds.push(item.textId); }
    done++;
    if (done % step === 0) figma.ui.postMessage({ type: "adjust-progress", done, total: list.length });
  }
  /* peça ajustada passa a guardar a lauda: da próxima vez é achada direto */
  const tagged = {};
  list.forEach(item => {
    if (!item.pieceId || !item.taxonomy || tagged[item.pieceId]) return;
    tagged[item.pieceId] = true;
    const pn = nodeById[item.pieceId];
    if (pn && !pn.removed) { try { pn.setPluginData(LAUDA_FLAG, item.taxonomy); } catch (_) {} }
  });
  /* o lote inteiro vira um passo só no Ctrl+Z do Figma */
  try { if (typeof figma.commitUndo === "function") figma.commitUndo(); } catch (_) {}
  return report;
}

/* ================= IMPORTAR ================= */
async function generatePieces(lines, direction, laudas, applyText, overrides) {
  const ov = overrides || {};
  direction = direction === "vertical" ? "vertical" : "horizontal";
  const state = await readState();
  const rowPrefs = state.rowPrefs || {};
  const applyOpts = normalizeAdjustPrefs(state.adjustPrefs);
  const catalog = normalizeCatalog(state.catalog);
  const matchers = createMatchers(catalog);
  /* formato escolhido à mão vence a detecção pelo nome */
  const matchOf = l => (ov[l] && catalog.formats[ov[l]]) ? { baseKey: ov[l], source: "manual" } : findFormat(l, matchers);
  const results = [], bundles = [];
  const laudaMap = {};
  (laudas || []).forEach(item => { laudaMap[String(item.line || "")] = item.lauda; });
  let cancelled = false, lineIdx = 0;
  /* dentro de cada formato, peças em ordem alfabética da taxonomia (A, B, C…);
     formatos na ordem em que aparecem na lista */
  {
    const clean = lines.map(l => String(l || "").trim()).filter(Boolean);
    const fmtOrder = {}, keyOf = {};
    clean.forEach(l => { const m = matchOf(l); const k = m ? m.baseKey : "~"; keyOf[l] = k; if (fmtOrder[k] === undefined) fmtOrder[k] = Object.keys(fmtOrder).length; });
    lines = clean.slice().sort((a, b) => (fmtOrder[keyOf[a]] - fmtOrder[keyOf[b]]) || natCmp(a, b));
  }
  const totalLines = lines.length;
  figma.ui.postMessage({ type: "op-progress", op: "generate", done: 0, total: totalLines });
  for (const raw of lines) {
    const line = String(raw || "").trim(); if (!line) continue;
    figma.ui.postMessage({ type: "op-progress", op: "generate", done: lineIdx, total: totalLines, label: line });
    lineIdx++;
    await tick();
    if (cancelFlag) { cancelled = true; break; }
    const match = matchOf(line);
    if (!match) { results.push(isAmbiguous(line, matchers) ? { line, status: "not_found", detail: "Formato ambíguo: o tamanho existe em mais de um formato. Escolha em Trocar formato." } : { line, status: "not_found" }); continue; }
    const entry = catalog.formats[match.baseKey];
    if (!entry || !entry.variants.length) { results.push({ line, status: "error", detail: "Formato sem variantes." }); continue; }
    const emailBlocked = applyText && applyOpts.blockEmail && isEmailFormat(entry, match.baseKey);
    const lauda = applyText && !emailBlocked ? laudaMap[line] : null;
    const bundle = { baseKey: match.baseKey, nodes: [], line };
    for (const variant of entry.variants) {
      const outputName = taxonomyName(line, variant.suffix);
      if (!variant.key) { results.push({ line: outputName, status: "error", detail: "Variante sem component key." }); continue; }
      try {
        const component = await figma.importComponentByKeyAsync(variant.key);
        const node = component.createInstance().detachInstance();
        node.name = outputName;
        try { node.setPluginData(TAX_FLAG, line); node.setPluginData(LAUDA_FLAG, lauda && lauda.taxonomy ? lauda.taxonomy : "");
          node.setPluginData(FMT_FLAG, [entry.displayName || match.baseKey].concat(entry.aliases || []).join(" | ")); } catch (_) {}
        bundle.nodes.push(node);
        let detail = "", status = "ok";
        /* avisos estruturados: a UI agrupa os que se repetem entre peças */
        const issues = [];
        let applied = null, laudaTax = "";
        if (applyText) {
          if (lauda) {
            const report = await applyLauda(node, lauda, applyOpts);
            applied = report.applied; laudaTax = lauda.taxonomy || "";
            if (!applyOpts.hideUnmatched) report.skipped.forEach(n => { if (!isFixedText(n, applyOpts.fixedText)) issues.push({ kind: "extra", label: n, info: true }); });
            report.warnings.forEach(w => {
              let m;
              if ((m = w.match(/^campo (.+) sem camada$/))) {
                /* leva o texto junto: sem ele não dá para saber o que ficou de fora */
                const f = (lauda.fields || []).find(x => x.key === m[1]);
                issues.push({ kind: "missing", label: m[1], value: f ? String(f.value || "") : "" });
              }
              else if ((m = w.match(/^(.+): (\d+)\/(\d+) car\.$/))) issues.push({ kind: "over", label: m[1], len: +m[2], limit: +m[3] });
              else issues.push({ kind: "other", label: w });
            });
            if (report.hidden + report.orphanHidden) issues.push({ kind: "hidden", label: report.hiddenNames.concat(report.orphanNames).join(", "), count: report.hidden + report.orphanHidden, info: true });
            detail = report.applied + " campo(s)";
            const totalHidden = report.hidden + report.orphanHidden;
            if (totalHidden) {
              const names = report.hiddenNames.concat(report.orphanNames);
              detail += " · " + totalHidden + " oculto(s): " + names.slice(0, 3).join(", ");
            }
            if (report.slotHidden) detail += " · " + report.slotHidden + " slot(s) sem texto na lauda";
            if (!applyOpts.hideUnmatched && report.skipped.length) {
              detail += " · " + report.skipped.length + " camada(s) fora da lauda: " + report.skipped.slice(0, 3).join(", ");
            }
            detail += " · " + (lauda.taxonomy || "lauda");
            if (report.warnings.length) { status = "warn"; detail += " · " + report.warnings.slice(0, 3).join(" · "); }
          } else if (emailBlocked) { detail = "email · texto da lauda bloqueado"; issues.push({ kind: "emailblock", label: "", info: true }); }
          else { status = "warn"; detail = "sem lauda correspondente"; issues.push({ kind: "nolauda", label: "" }); }
        }
        results.push({ line: outputName, status, matchedBy: match.source, detail, id: node.id, issues, applied, lauda: laudaTax, base: line });
      } catch (error) { results.push({ line: outputName, status: "error", detail: error && error.message ? error.message : String(error) }); }
    }
    if (bundle.nodes.length) bundles.push(bundle);
  }
  if (bundles.length) {
    const gap = 40, groupGap = 120;
    const baseX = figma.viewport.center.x - 200, baseY = figma.viewport.center.y - 200;
    const runs = [], runIndex = {};
    bundles.sort((a, b) => natCmp(a.line || "", b.line || ""));
    bundles.forEach(bundle => {
      let run = runIndex[bundle.baseKey];
      if (!run) { run = { baseKey: bundle.baseKey, bundles: [] }; runIndex[bundle.baseKey] = run; runs.push(run); }
      run.bundles.push(bundle);
    });
    function layoutBundle(bundle, x, y) {
      let h = 0, w = 0;
      bundle.nodes.forEach(node => {
        figma.currentPage.appendChild(node);
        node.x = x; node.y = y + h;
        h += node.height + gap;
        w = Math.max(w, node.width);
      });
      return { width: w, height: Math.max(0, h - gap) };
    }
    function layoutRun(run, x, y) {
      const entry = catalog.formats[run.baseKey] || {};
      const pref = rowPrefs[run.baseKey];
      const perRow = Number(pref !== undefined && pref !== null ? pref : entry.maxPerRow) || 0;
      const total = run.bundles.length;
      const cols = perRow > 0 ? Math.min(perRow, total) : total;
      const sizes = run.bundles.map(bundle => {
        let h = 0, w = 0;
        bundle.nodes.forEach(node => { h += node.height + gap; w = Math.max(w, node.width); });
        return { width: w, height: Math.max(0, h - gap) };
      });
      const colWidth = Math.max.apply(null, sizes.map(s => s.width).concat([1]));
      const rowCount = Math.ceil(total / cols);
      const rowHeights = [];
      for (let r = 0; r < rowCount; r++) {
        let tallest = 0;
        for (let c = 0; c < cols; c++) { const it = sizes[r * cols + c]; if (it && it.height > tallest) tallest = it.height; }
        rowHeights.push(tallest);
      }
      let cy = y;
      for (let r = 0; r < rowCount; r++) {
        for (let c = 0; c < cols; c++) {
          const bundle = run.bundles[r * cols + c];
          if (!bundle) break;
          layoutBundle(bundle, x + c * (colWidth + gap), cy);
        }
        cy += rowHeights[r] + gap;
      }
      return { width: cols * colWidth + (cols - 1) * gap, height: Math.max(0, cy - y - gap) };
    }
    if (direction === "horizontal") { let x = baseX; runs.forEach(run => { const s = layoutRun(run, x, baseY); x += s.width + groupGap; }); }
    else { let y = baseY; runs.forEach(run => { const s = layoutRun(run, baseX, y); y += s.height + groupGap; }); }
    const nodes = [];
    bundles.forEach(bundle => bundle.nodes.forEach(node => nodes.push(node)));
    figma.currentPage.selection = nodes;
    figma.viewport.scrollAndZoomIntoView(nodes);
  }
  results.cancelled = cancelled;
  results.totalLines = totalLines;
  return results;
}

/* ═══════════════════ MÓDULO: EXPORT - SANTANDER ═══════════════════
   Código original preservado. As únicas adaptações são de convivência:
   · mensagens saem/entram com o prefixo "ex:" para não colidir com o hub
   · showUI e resize removidos (a janela é do hub)
   · sendInit sob demanda, quando a aba Exportar ou uma seção dele abre
   Chaves de pluginData (`export-models:*`) já eram namespacedas.
   ═══════════════════════════════════════════════════════════════════ */
function exPost(msg) {
  const out = {};
  Object.keys(msg || {}).forEach(k => { out[k] = msg[k]; });
  out.type = 'ex:' + msg.type;
  figma.ui.postMessage(out);
}
const TOOL_ID = 'export-models';
const DISPLAY_NAME = 'Export - santander';
const TOGGLES_KEY = `${TOOL_ID}:toggles`;
const RULES_KEY = `${TOOL_ID}:format-rules`;
/* só o embaralhado (SHA-256 com sal) fica no código — a senha em si não */
const PASS_SALT = 'autopecas:v1:';
const PASS_HASH = '06ef1850e406bacfb2bea9dbde7ea1fdb2d5c297695cccb43384ba4ad4188178';
/* SHA-256 em JS puro: o sandbox do Figma (code.js) nao tem crypto.subtle,
   e a UI roda em iframe de origem null, onde ele pode nao existir. */
function sha256hex(str){
  var ascii=unescape(encodeURIComponent(String(str)));
  function rr(v,a){return(v>>>a)|(v<<(32-a))}
  var maxWord=Math.pow(2,32),result='',words=[],bitLen=ascii.length*8,hash=[],k=[],pc=0,comp={},i,j;
  for(var c=2;pc<64;c++){if(!comp[c]){for(i=0;i<313;i+=c)comp[i]=c;hash[pc]=(Math.pow(c,.5)*maxWord)|0;k[pc++]=(Math.pow(c,1/3)*maxWord)|0}}
  hash=hash.slice(0,8);
  ascii+='\x80';while(ascii.length%64-56)ascii+='\x00';
  for(i=0;i<ascii.length;i++){j=ascii.charCodeAt(i);words[i>>2]|=j<<((3-i)%4)*8}
  words[words.length]=((bitLen/maxWord)|0);words[words.length]=bitLen;
  for(j=0;j<words.length;){var w=words.slice(j,j+=16),old=hash;hash=hash.slice(0,8);
    for(i=0;i<64;i++){var w15=w[i-15],w2=w[i-2],a=hash[0],e=hash[4];
      var t1=hash[7]+(rr(e,6)^rr(e,11)^rr(e,25))+((e&hash[5])^((~e)&hash[6]))+k[i]
        +(w[i]=(i<16)?w[i]:(w[i-16]+(rr(w15,7)^rr(w15,18)^(w15>>>3))+w[i-7]+(rr(w2,17)^rr(w2,19)^(w2>>>10)))|0);
      var t2=(rr(a,2)^rr(a,13)^rr(a,22))+((a&hash[1])^(a&hash[2])^(hash[1]&hash[2]));
      hash=[(t1+t2)|0].concat(hash);hash[4]=(hash[4]+t1)|0}
    for(i=0;i<8;i++)hash[i]=(hash[i]+old[i])|0}
  for(i=0;i<8;i++)for(j=3;j+1;j--){var b=(hash[i]>>(j*8))&255;result+=(b<16?'0':'')+b.toString(16)}
  return result}

const DEFAULT_TOGGLES = [
    { id: 'peca', label: 'Peça', format: 'PNG', scale: 1, variable: '', subfolder: '', mode: 'full', layerRules: [] },
    { id: 'fundo', label: 'Fundo', format: 'PNG', scale: 1, variable: 'fundo', subfolder: '', mode: 'only', layerRules: [{ name: 'fundo', enabled: true }, { name: 'bg', enabled: true }, { name: 'background', enabled: true }] },
    { id: 'icone', label: 'Icone', format: 'PNG', scale: 1, variable: 'icone', subfolder: '', mode: 'only', layerRules: [{ name: 'icone', enabled: true }, { name: 'icon', enabled: true }] },
    { id: 'imagem', label: 'Imagem', format: 'PNG', scale: 1, variable: 'imagem', subfolder: '', mode: 'only', layerRules: [{ name: 'imagem', enabled: true }, { name: 'image', enabled: true }, { name: 'img', enabled: true }] },
];
const DEFAULT_FORMAT_RULES = [
    { label: 'Alert / Alerts', keywords: ['alert', 'alerts'], tags: ['peca', 'fundo'], components: 'Peça + Fundo' },
    { label: 'CommercialBanner / Banner One App', keywords: ['commercialbanner', 'banner one app'], tags: ['peca', 'fundo'], components: 'Peça + Fundo' },
    { label: 'Comprovante Pix / CardPix', keywords: ['comprovante pix', 'cardpix'], tags: ['peca', 'fundo', 'icone'], components: 'Peça + Fundo + Icone' },
    { label: 'Lightbox', keywords: ['lightbox'], tags: ['peca', 'imagem'], components: 'Peça + Imagem' },
    { label: 'Product Category', keywords: ['product category'], tags: ['peca', 'icone'], components: 'Peça + Icone' },
    { label: 'Recommended / PromotedProducts', keywords: ['recommended', 'promotedproducts'], tags: ['peca', 'imagem'], components: 'Peça + Imagem' },
    { label: 'Push', keywords: ['push'], tags: ['peca', 'imagem'], components: 'Peça + Imagem' },
    { label: 'Interstitial', keywords: ['interstitial'], tags: ['peca', 'imagem'], components: 'Peça + Imagem' },
    { label: 'Card Cartao', keywords: ['card cartao', 'card cartão'], tags: ['peca', 'imagem'], components: 'Peça + Imagem' },
    { label: 'Banner Destaque', keywords: ['banner destaque'], tags: ['peca', 'imagem'], components: 'Peça + Imagem' },
    { label: 'Lista de Oferta', keywords: ['lista de oferta'], tags: ['peca', 'fundo', 'icone'], components: 'Peça + Fundo + Icone' },
    { label: 'Card Jornada', keywords: ['card jornada'], tags: ['peca', 'fundo', 'icone'], components: 'Peça + Fundo + Icone' },
    { label: 'Aviso Importante', keywords: ['aviso importante'], tags: ['peca', 'fundo'], components: 'Peça + Fundo' },
    { label: 'Comprovante Banner', keywords: ['comprovante banner'], tags: ['peca', 'fundo'], components: 'Peça + Fundo' },
    { label: 'Emprestimo Banner', keywords: ['emprestimo banner', 'empréstimo banner'], tags: ['peca', 'fundo', 'imagem'], components: 'Peça + Fundo + Imagem' },
    { label: 'Gestao Limites Banner', keywords: ['gestao limites banner', 'gestão limites banner'], tags: ['peca', 'fundo', 'imagem'], components: 'Peça + Fundo + Imagem' },
    { label: 'Home Lightbox', keywords: ['home lightbox'], tags: ['peca', 'imagem'], components: 'Peça + Imagem' },
    { label: 'Banner Nao Logado (BNL)', keywords: ['banner nao logado', 'banner não logado', 'bnl'], tags: ['peca', 'imagem'], components: 'Peça + Imagem' },
    { label: 'Card Home', keywords: ['card home'], tags: ['peca', 'fundo', 'icone'], components: 'Peça + (Fundo + Icone) + Icone' },
    { label: 'Carrossel Comercial Superior', keywords: ['carrossel comercial superior'], tags: ['peca', 'fundo'], components: 'Peça + Fundo' },
    { label: 'Comprovante Pix MBPJ', keywords: ['comprovante pix mbpj'], tags: ['peca', 'imagem'], components: 'Peça + Imagem' },
    { label: 'Gestao de Limites MBPJ', keywords: ['gestao de limites mbpj', 'gestão de limites mbpj'], tags: ['peca', 'imagem'], components: 'Peça + Imagem' },
    { label: 'SUPERBANNER', keywords: ['superbanner'], tags: ['peca', 'fundo', 'imagem'], components: 'Peça + (Fundo + Imagem) + Imagem' },
    { label: 'Importante Para Voce', keywords: ['importante para voce', 'importante para você'], tags: ['peca', 'fundo', 'imagem'], components: 'Peça + (Fundo + Imagem) + Imagem' },
    { label: 'Card Parceiros', keywords: ['card parceiros'], tags: ['peca', 'fundo'], components: 'Peça + Fundo' },
    { label: 'banner App', keywords: ['bannerapp', 'banner app', 'banner_app'], tags: ['peca', 'imagem'], components: 'Peca + Imagem' },
    { label: 'Email / EMKT', keywords: ['email', 'emkt', 'e-mail'], tags: ['peca'], components: 'Peça em 4x', pecaScale: 4 },
    { label: 'Carrossel', keywords: ['carrossel'], tags: ['peca', 'fundo'], components: 'Peça + Fundo' },
];
function loadToggles() {
    try {
        const raw = figma.root.getPluginData(TOGGLES_KEY);
        if (!raw)
            return DEFAULT_TOGGLES.map(t => (Object.assign(Object.assign({}, t), { layerRules: t.layerRules.map(r => (Object.assign({}, r))) })));
        const p = JSON.parse(raw);
        return Array.isArray(p) && p.length > 0 ? p : DEFAULT_TOGGLES.map(t => (Object.assign(Object.assign({}, t), { layerRules: t.layerRules.map(r => (Object.assign({}, r))) })));
    }
    catch (_a) {
        return DEFAULT_TOGGLES.map(t => (Object.assign(Object.assign({}, t), { layerRules: t.layerRules.map(r => (Object.assign({}, r))) })));
    }
}
function saveToggles(t) { figma.root.setPluginData(TOGGLES_KEY, JSON.stringify(t)); }
function loadFormatRules() {
    try {
        const raw = figma.root.getPluginData(RULES_KEY);
        if (!raw)
            return DEFAULT_FORMAT_RULES.map(r => (Object.assign(Object.assign({}, r), { keywords: [...r.keywords], tags: [...r.tags] })));
        const p = JSON.parse(raw);
        return Array.isArray(p) && p.length > 0 ? p : DEFAULT_FORMAT_RULES.map(r => (Object.assign(Object.assign({}, r), { keywords: [...r.keywords], tags: [...r.tags] })));
    }
    catch (_a) {
        return DEFAULT_FORMAT_RULES.map(r => (Object.assign(Object.assign({}, r), { keywords: [...r.keywords], tags: [...r.tags] })));
    }
}
function saveFormatRules(r) { figma.root.setPluginData(RULES_KEY, JSON.stringify(r)); }
function normalizeStr(s) {
    return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ');
}
function detectFormat(frameName, rules) {
    if (!frameName)
        return null;
    const norm = normalizeStr(frameName);
    const sorted = rules.slice().sort((a, b) => {
        const ma = Math.max(...a.keywords.map(k => k.length));
        const mb = Math.max(...b.keywords.map(k => k.length));
        return mb - ma;
    });
    for (const rule of sorted) {
        for (const kw of rule.keywords) {
            if (norm.includes(normalizeStr(kw)))
                return rule;
        }
    }
    return null;
}
function toggleMatchesTag(entry, tag) {
    const v = normalizeStr(entry.variable || '');
    const l = normalizeStr(entry.label || '');
    switch (tag) {
        case 'peca': return entry.mode === 'full' && !(entry.variable || '').trim();
        case 'fundo': return v.includes('fundo') || v.includes('bg') || v.includes('background') || l.includes('fundo') || l.includes('background');
        case 'icone': return v.includes('icon') || v.includes('icone') || l.includes('icon') || l.includes('icone');
        case 'imagem': return v.includes('imagem') || v.includes('img') || v.includes('image') || l.includes('imagem') || l.includes('image');
        default: return false;
    }
}
function findLayersByRules(parent, rules) {
    const names = rules.filter(r => r.enabled).map(r => r.name.toUpperCase());
    if (names.length === 0)
        return [];
    const result = [];
    function walk(node) {
        if (names.some(n => node.name.toUpperCase().includes(n))) {
            result.push(node);
            return;
        }
        if ('children' in node) {
            for (const c of node.children)
                walk(c);
        }
    }
    if ('children' in parent) {
        for (const c of parent.children)
            walk(c);
    }
    return result;
}
/* Pasta do export = taxonomia da peça.
   · Sem sufixo de versão: o nome inteiro, como está ("_A" e "_A_" ficam separados).
   · Com sufixo de versão (desk, mobi, desdob…): o sufixo sai e as versões do
     mesmo ID ficam juntas. Peça criada pelo plugin usa a taxonomia gravada,
     que preserva o "_" final exatamente como veio da lauda. */
const FOLDER_SUFFIXES = ["desktop", "desdob", "desd", "desk", "mobile", "mobi", "tablet"];
function folderOf(frame) {
  const name = String(frame.name || "").trim();
  const lower = name.toLowerCase();
  let base = null;
  outer: for (const s of FOLDER_SUFFIXES) {
    for (const sep of ["_", "-", " "]) {
      for (const tail of ["", "_"]) {
        const ending = sep + s + tail;
        if (lower.endsWith(ending) && lower.length > ending.length) { base = name.slice(0, -ending.length); break outer; }
      }
    }
  }
  if (base === null) return name;
  let stored = "";
  try { stored = frame.getPluginData(TAX_FLAG) || ""; } catch (_) {}
  if (stored && (stored === base || stored === base + "_")) return stored;
  return base;
}
function buildGroupFolderMap(frames) {
  const m = {};
  for (const f of frames) m[f.id] = folderOf(f).replace(/[\\/:*?"<>|]/g, "_");
  return m;
}
function uint8ToBase64(bytes) {
    let b = '';
    for (let i = 0; i < bytes.byteLength; i++)
        b += String.fromCharCode(bytes[i]);
    return btoa(b);
}
figma.root.setRelaunchData({ [TOOL_ID]: DISPLAY_NAME });
function fmtHint(n) { try { return n.getPluginData(FMT_FLAG) || ""; } catch (_) { return ""; } }
function ruleFor(frame, rules) {
  const hint = fmtHint(frame);
  if (hint) { for (const part of hint.split(" | ")) { const r = detectFormat(part, rules); if (r) return r; } }
  return detectFormat(frame.name, rules);
}
function sendInit() {
    const sel = figma.currentPage.selection;
    exPost({
        type: 'init',
        toggles: loadToggles(),
        formatRules: loadFormatRules(),
        hasSelection: sel.length > 0,
        frameName: sel.length > 0 ? sel[0].name : '',
        selCount: sel.length,
        frames: sel.map(n => ({ id: n.id, name: n.name, hint: fmtHint(n) })),
        fileName: figma.root.name || 'Export',
    });
}
function exOnSelectionChange() {
    const s = figma.currentPage.selection;
    exPost({
        type: 'selection', hasSelection: s.length > 0,
        frameName: s.length > 0 ? s[0].name : '', selCount: s.length,
        frames: s.map(n => ({ id: n.id, name: n.name, hint: fmtHint(n) })),
    });
}
async function exHandleMessage(msg) {
    var _a;
    if (msg.type === 'resize') return; // altura e controlada pelo hub
    if (msg.type === 'check-password') {
        exPost({ type: 'password-result', ok: sha256hex(PASS_SALT + String(msg.password || '')) === PASS_HASH });
        return;
    }
    if (msg.type === 'save-toggles') {
        if (msg.toggles)
            saveToggles(msg.toggles);
        return;
    }
    if (msg.type === 'save-format-rules') {
        if (msg.rules)
            saveFormatRules(msg.rules);
        return;
    }
    if (msg.type === 'capture-selection') {
        const cs = figma.currentPage.selection;
        if (cs.length === 0) {
            figma.notify('Selecione as camadas no canvas primeiro');
            return;
        }
        exPost({ type: 'captured-names', entryIndex: msg.entryIndex, names: cs.map(n => n.name) });
        figma.notify(`${cs.length} camada${cs.length > 1 ? 's' : ''} adicionada${cs.length > 1 ? 's' : ''}`);
        return;
    }
    if (msg.type === 'export') {
        const frames = figma.currentPage.selection;
        if (frames.length === 0) {
            figma.notify('Selecione os frames para exportar');
            return;
        }
        const version = (msg.version || '').trim() || 'v0';
        const allToggles = loadToggles();
        const allRules = loadFormatRules();
        const fName = figma.root.name || 'Export';
        const safeFileName = fName.replace(/[\\/:*?"<>|]/g, '_');
        const jobs = [];
        let total = 0;
        for (const frame of frames) {
            const rule = ruleFor(frame, allRules);
            let entries;
            if (rule) {
                entries = allToggles.filter(t => rule.tags.some(tag => toggleMatchesTag(t, tag)));
                if (rule.pecaScale) {
                    entries = entries.map(e => {
                        if (toggleMatchesTag(e, 'peca'))
                            return Object.assign(Object.assign({}, e), { scale: rule.pecaScale });
                        return e;
                    });
                }
            }
            else {
                entries = allToggles;
            }
            jobs.push({ frame, entries, rule });
            total += entries.length;
        }
        if (total === 0) {
            figma.notify('Nenhum componente combina com os frames selecionados.');
            return;
        }
        const dets = [...new Set(jobs.filter(j => j.rule).map(j => j.rule.label))];
        figma.notify(`Exportando ${frames.length} frame(s)${dets.length ? ' (' + dets.join(', ') + ')' : ''} — ${total} arquivo(s)…`);
        exPost({ type: 'export-progress', current: 0, total });
        const allFiles = [];
        let progress = 0;
        const groupMap = buildGroupFolderMap(frames);
        for (const { frame, entries, rule: jobRule } of jobs) {
            const frameName = frame.name;
            const groupFolder = groupMap[frame.id] || frameName;
            for (const entry of entries) {
                const variable = (entry.variable || '').trim();
                const hiddenBefore = [];
                const rules = entry.layerRules || [];
                if (entry.mode === 'hide' && rules.length > 0) {
                    const matched = findLayersByRules(frame, rules);
                    for (const node of matched) {
                        if (node.visible) {
                            hiddenBefore.push({ node, wasVisible: true });
                            node.visible = false;
                        }
                    }
                }
                let onlyNodes = [];
                if (entry.mode === 'only') {
                    onlyNodes = rules.length > 0 ? findLayersByRules(frame, rules) : (variable ? findLayersByRules(frame, [{ name: variable, enabled: true }]) : []);
                    if (onlyNodes.length === 0) {
                        progress++;
                        exPost({ type: 'export-progress', current: progress, total });
                        continue;
                    }
                }
                let settings;
                if (entry.format === 'SVG')
                    settings = { format: 'SVG' };
                else if (entry.format === 'PDF')
                    settings = { format: 'PDF' };
                else
                    settings = { format: entry.format, constraint: { type: 'SCALE', value: entry.scale } };
                try {
                    let bytes;
                    if (entry.mode === 'only' && onlyNodes.length > 0) {
                        if (onlyNodes.length === 1) {
                            bytes = await onlyNodes[0].exportAsync(settings);
                        }
                        else {
                            let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
                            for (const n of onlyNodes) {
                                const tx = n.absoluteTransform[0][2], ty = n.absoluteTransform[1][2];
                                minX = Math.min(minX, tx);
                                minY = Math.min(minY, ty);
                                maxX = Math.max(maxX, tx + n.width);
                                maxY = Math.max(maxY, ty + n.height);
                            }
                            const tmp = figma.createFrame();
                            tmp.name = '__tmp__';
                            tmp.x = -9999;
                            tmp.y = -9999;
                            tmp.resize(Math.max(1, maxX - minX), Math.max(1, maxY - minY));
                            tmp.fills = [];
                            tmp.clipsContent = true;
                            for (const n of onlyNodes) {
                                const cl = n.clone();
                                tmp.appendChild(cl);
                                cl.x = n.absoluteTransform[0][2] - minX;
                                cl.y = n.absoluteTransform[1][2] - minY;
                            }
                            bytes = await tmp.exportAsync(settings);
                            tmp.remove();
                        }
                    }
                    else {
                        bytes = await frame.exportAsync(settings);
                    }
                    const ext = entry.format.toLowerCase();
                    const baseName = variable ? `${frameName}_${variable}` : frameName;
                    const fileNameOnly = `${baseName}.${ext}`;
                    const parts = [safeFileName, groupFolder, version, fileNameOnly];
                    allFiles.push({ fileName: parts.join('/'), base64: uint8ToBase64(bytes), mimeType: ext === 'svg' ? 'image/svg+xml' : ext === 'pdf' ? 'application/pdf' : `image/${ext}`, toggleLabel: entry.label, frameName, formatLabel: jobRule ? jobRule.label : '' });
                }
                catch (e) {
                    figma.notify(`Erro: ${frameName} (${entry.label}): ${e instanceof Error ? e.message : String(e)}`);
                }
                for (const item of hiddenBefore)
                    item.node.visible = item.wasVisible;
                progress++;
                exPost({ type: 'export-progress', current: progress, total });
            }
        }
        figma.notify(`Pronto! ${allFiles.length} arquivo(s) no ZIP.`);
        exPost({ type: 'export-done', files: allFiles, fileName: fName });
    }
}

/* ═══════════════════ ROTEADOR DO HUB ═══════════════════ */
let exBooted = false;
figma.on("selectionchange", () => { if (exBooted) exOnSelectionChange(); });

figma.ui.onmessage = async msg => {
  if (!msg || !msg.type) return;

  if (String(msg.type).indexOf("ex:") === 0) {
    const inner = {};
    Object.keys(msg).forEach(k => { inner[k] = msg[k]; });
    inner.type = String(msg.type).slice(3);
    if (inner.type === "boot") { exBooted = true; sendInit(); return; }
    await exHandleMessage(inner);
    return;
  }

  if (msg.type === "resize") {
    const cap = Math.min(Number(msg.maxHeight) || MAX_UI_HEIGHT, MAX_UI_HEIGHT);
    figma.ui.resize(msg.width || 460, Math.max(MIN_UI_HEIGHT, Math.min(Number(msg.height) || 720, cap)));
    return;
  }
  if (msg.type === "get-state") {
    const state = await readState();
    figma.ui.postMessage({ type: "state", state, health: catalogHealth(normalizeCatalog(state.catalog)) });
    return;
  }
  if (msg.type === "set-theme") {
    const state = await readState();
    state.theme = normalizeTheme(msg.theme);
    await saveState(state);
    figma.ui.postMessage({ type: "theme-saved", theme: state.theme });
    return;
  }
  if (msg.type === "save-catalog") {
    const state = await readState();
    state.catalog = normalizeCatalog(msg.catalog || { formats: {} });
    state.dirty = true;
    await saveState(state);
    figma.ui.postMessage({ type: "saved", state, health: catalogHealth(normalizeCatalog(state.catalog)) });
    return;
  }
  if (msg.type === "sync-remote") {
    const state = await readState();
    if (msg.auto && state.dirty) {
      figma.ui.postMessage({ type: "sync-result", ok: false, skipped: true, error: "Alteracoes locais nao publicadas.", state, health: catalogHealth(normalizeCatalog(state.catalog)) });
      return;
    }
    try {
      state.catalog = await fetchRemoteCatalog(DEFAULT_REMOTE_URL);
      state.remoteUrl = DEFAULT_REMOTE_URL;
      state.syncedAt = new Date().toISOString();
      state.dirty = false;
      await saveState(state);
      figma.ui.postMessage({ type: "sync-result", ok: true, state, health: catalogHealth(normalizeCatalog(state.catalog)) });
    } catch (error) {
      figma.ui.postMessage({ type: "sync-result", ok: false, error: error && error.message ? error.message : String(error), state });
    }
    return;
  }
  if (msg.type === "extract-library") {
    const state = await readState();
    try {
      const components = await extractComponentsFromFile();
      state.catalog = mergeLibrary(state.catalog, components);
      state.dirty = true;
      await saveState(state);
      figma.ui.postMessage({ type: "library-result", components: components.length, state, health: catalogHealth(normalizeCatalog(state.catalog)) });
    } catch (error) {
      figma.ui.postMessage({ type: "library-error", error: error && error.message ? error.message : String(error) });
    }
    return;
  }
  if (msg.type === "set-row-pref") {
    const state = await readState();
    state.rowPrefs = state.rowPrefs || {};
    const value = Number(msg.value) || 0;
    if (value > 0) state.rowPrefs[msg.key] = value; else delete state.rowPrefs[msg.key];
    await saveState(state);
    figma.ui.postMessage({ type: "row-pref-saved", rowPrefs: state.rowPrefs });
    return;
  }
  if (msg.type === "set-adjust-prefs") {
    const state = await readState();
    state.adjustPrefs = normalizeAdjustPrefs(msg.prefs);
    await saveState(state);
    figma.ui.postMessage({ type: "adjust-prefs-saved", adjustPrefs: state.adjustPrefs });
    return;
  }
  if (msg.type === "mark-published") {
    const state = await readState();
    state.dirty = false;
    await saveState(state);
    figma.ui.postMessage({ type: "saved", state, health: catalogHealth(normalizeCatalog(state.catalog)) });
    return;
  }
  if (msg.type === "cancel-op") { cancelFlag = true; return; }
  if (msg.type === "check-existing") {
    const want = {};
    (msg.lines || []).forEach(l => { const k = normalize(l); if (k) want[k] = l; });
    const found = {};
    try {
      if (typeof figma.currentPage.loadAsync === "function") await figma.currentPage.loadAsync();
      figma.currentPage.children.forEach(n => {
        let tax = ""; try { tax = n.getPluginData(TAX_FLAG) || ""; } catch (_) {}
        [tax, splitSuffix(n.name).base, n.name].forEach(c => { const k = normalize(c); if (k && want[k]) found[want[k]] = true; });
      });
    } catch (_) {}
    figma.ui.postMessage({ type: "existing", lines: Object.keys(found) });
    return;
  }
  if (msg.type === "generate") {
    cancelFlag = false;
    const results = await generatePieces(msg.lines || [], msg.direction, msg.laudas || [], !!msg.applyText, msg.overrides || {});
    figma.ui.postMessage({ type: "generate-result", results, cancelled: !!results.cancelled, total: results.totalLines || 0 });
    cancelFlag = false;
    return;
  }
  if (msg.type === "scan-adjust") {
    try {
      cancelFlag = false;
      const result = await scanAdjust(msg.laudas || [], msg.scope, msg.prefs, msg.ids);
      cancelFlag = false;
      figma.ui.postMessage({ type: "adjust-scan", ok: !result.error, pieces: result.pieces || [], error: result.error || "", cancelled: !!result.cancelled, total: result.total || 0 });
    } catch (error) {
      figma.ui.postMessage({ type: "adjust-scan", ok: false, pieces: [], error: error && error.message ? error.message : String(error) });
    }
    return;
  }
  if (msg.type === "apply-adjust") {
    try {
      const report = await applyAdjust(msg.items || [], msg.prefs);
      figma.ui.postMessage({ type: "adjust-applied", ok: true, report });
    } catch (error) {
      figma.ui.postMessage({ type: "adjust-applied", ok: false, error: error && error.message ? error.message : String(error) });
    }
    return;
  }
  /* sessão salva no arquivo: laudas, lista, comparação e registro de ajustes */
  if (msg.type === "save-session") {
    try { figma.root.setPluginData(SESSION_KEY, String(msg.json || "")); } catch (e) {
      figma.ui.postMessage({ type: "session-error", error: e && e.message ? e.message : String(e) });
    }
    return;
  }
  if (msg.type === "load-session") {
    let json = "";
    try { json = figma.root.getPluginData(SESSION_KEY) || ""; } catch (_) {}
    figma.ui.postMessage({ type: "session", json });
    return;
  }
  /* seleciona várias peças no canvas (para exportar) */
  if (msg.type === "select-nodes") {
    const nodes = []; let missing = 0;
    for (const id of msg.ids || []) {
      try { const n = await figma.getNodeByIdAsync(id); if (n && !n.removed) nodes.push(n); else missing++; } catch (_) { missing++; }
    }
    if (!nodes.length) { figma.ui.postMessage({ type: "select-result", ok: false, count: 0, missing }); return; }
    const pageOf = n => { let p = n; while (p && p.type !== "PAGE") p = p.parent; return p; };
    const page = pageOf(nodes[0]);
    if (page && page !== figma.currentPage) {
      if (typeof figma.setCurrentPageAsync === "function") await figma.setCurrentPageAsync(page);
      else figma.currentPage = page;
    }
    const here = nodes.filter(n => pageOf(n) === figma.currentPage);
    figma.currentPage.selection = here;
    figma.viewport.scrollAndZoomIntoView(here);
    figma.ui.postMessage({ type: "select-result", ok: true, count: here.length, missing, other: nodes.length - here.length });
    return;
  }
  if (msg.type === "focus-node") {
    try {
      const node = await figma.getNodeByIdAsync(msg.id);
      if (!node || node.removed) { figma.ui.postMessage({ type: "focus-result", ok: false }); return; }
      let page = node;
      while (page && page.type !== "PAGE") page = page.parent;
      if (page && page !== figma.currentPage) {
        if (typeof figma.setCurrentPageAsync === "function") await figma.setCurrentPageAsync(page);
        else figma.currentPage = page;
      }
      figma.currentPage.selection = [node];
      figma.viewport.scrollAndZoomIntoView([node]);
      figma.ui.postMessage({ type: "focus-result", ok: true });
    } catch (_) { figma.ui.postMessage({ type: "focus-result", ok: false }); }
    return;
  }
};
